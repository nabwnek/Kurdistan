package com.kurdistan.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.ExtractedText;
import android.view.inputmethod.ExtractedTextRequest;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.content.res.ColorStateList;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;

public class KurdistanIME extends InputMethodService {

    private int currentLang = 0;
    private boolean isShift = false;
    private LinearLayout keysContainer;
    private Button btnKu, btnEn, btnAr;
    private LinearLayout rootView;
    private LinearLayout langRow;
    private TextView suggestionBar;
    private Handler handler = new Handler(Looper.getMainLooper());
    private StringBuilder currentWord = new StringBuilder();

    // Kurdish word suggestions
    private final String[] kurdishWords = {
        "کوردستان","کوردی","باشە","سڵاو","چۆنی","سپاس","خۆشە","باشترە","بەڵێ","نەخێر",
        "دەتوانم","دەمەوێ","ئەمە","ئەوە","کاتێک","چونکە","بۆ","لەگەڵ","پێش","دوای",
        "ئێمە","ئێوە","ئەوان","کەس","شت","جار","وەکو","هەر","تەنها","زۆر",
        "کتێب","خوێندن","نووسین","قسەکردن","کار","ماڵ","شار","گوند","رووبار","چیا",
        "دایک","باوک","براد","خوشک","کوڕ","کچ","هاوڕێ","ئارەزوو","خەون","ژیان",
        "ئاو","نان","خواردن","خەوتن","ڕۆیشتن","هاتن","دیتن","گوێڕایەڵ","فێربوون",
        "ئەمڕۆ","دوێنێ","سبەینێ","ئێوارە","بەیانی","شەو","رۆژ","هەفتە","مانگ","ساڵ",
        "دەبێت","ناکرێت","دەکرێت","بکە","مەکە","هەیە","نییە","بووە","دەبوو",
        "خۆشحاڵم","خەمگینم","تووڕەم","شادم","تەنیام","دڵتەنگم","ئارامم",
        "رازیم","قبووڵم","هاوکاری","یارمەتی","پشتیوانی","خزمەت","کۆمەڵگا"
    };

    private final String[][] kurdish = {
        {"ق","و","ئ","ر","ت","ی","ئو","ح","ۆ","پ","⌫"},
        {"ا","س","د","ف","گ","ه","ج","ک","ل","؛"},
        {"⇧","ز","خ","چ","ڤ","ب","ن","م","،","."},
        {"زمان","🗑","         ","📋","↵"}
    };
    private final String[][] kurdish2 = {
        {"ژ","ێ","ع","ڕ","ت","ی","ئو","ح","ۆ","پ","⌫"},
        {"ا","ش","د","ف","غ","ه","ج","ک","ل","؛"},
        {"⇧","ز","خ","چ","ڤ","ب","ن","م","،","."},
        {"زمان","🗑","         ","📋","↵"}
    };
    private final String[][] english = {
        {"q","w","e","r","t","y","u","i","o","p","⌫"},
        {"a","s","d","f","g","h","j","k","l",";"},
        {"⇧","z","x","c","v","b","n","m",",","."},
        {"Lang","🗑","         ","📋","↵"}
    };
    private final String[][] englishUp = {
        {"Q","W","E","R","T","Y","U","I","O","P","⌫"},
        {"A","S","D","F","G","H","J","K","L",":"},
        {"⇧","Z","X","C","V","B","N","M","<",">"},
        {"Lang","🗑","         ","📋","↵"}
    };
    private final String[][] arabic = {
        {"ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","⌫"},
        {"ش","س","ي","ب","ل","ا","ت","ن","م","ك"},
        {"⇧","ئ","ء","ؤ","ر","ى","ة","و","ز","ظ"},
        {"لغة","🗑","         ","📋","↵"}
    };

    @Override
    public View onCreateInputView() {
        rootView = new LinearLayout(this);
        rootView.setOrientation(LinearLayout.VERTICAL);
        rootView.setBackgroundColor(Color.parseColor("#0d1117"));
        rootView.setPadding(3,3,3,3);

        // Suggestion bar
        HorizontalScrollView scrollSugg = new HorizontalScrollView(this);
        scrollSugg.setBackgroundColor(Color.parseColor("#161b22"));
        LinearLayout suggRow = new LinearLayout(this);
        suggRow.setOrientation(LinearLayout.HORIZONTAL);
        suggRow.setPadding(4,2,4,2);
        scrollSugg.addView(suggRow);

        // Build suggestion buttons placeholder — will be updated dynamically
        for (int i = 0; i < 8; i++) {
            Button s = new Button(this);
            s.setTextColor(Color.parseColor("#58a6ff"));
            s.setTextSize(14);
            s.setTypeface(null, Typeface.BOLD);
            s.setVisibility(View.GONE);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(38));
            sp.setMargins(3,2,3,2);
            s.setLayoutParams(sp);
            s.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#21262d")));
            suggRow.addView(s);
        }
        rootView.addView(scrollSugg);
        suggestionBar = new TextView(this); // dummy ref
        // Store suggRow ref for updates
        rootView.setTag(suggRow);

        // Lang row
        langRow = new LinearLayout(this);
        langRow.setOrientation(LinearLayout.HORIZONTAL);
        langRow.setPadding(0,2,0,2);

        btnKu = makeLangBtn("کوردی", true);
        btnEn = makeLangBtn("English", false);
        btnAr = makeLangBtn("عربی", false);

        btnKu.setOnClickListener(v -> { currentLang=0; isShift=false; updateLang(); rebuildKeys(); });
        btnEn.setOnClickListener(v -> { currentLang=1; isShift=false; updateLang(); rebuildKeys(); });
        btnAr.setOnClickListener(v -> { currentLang=2; isShift=false; updateLang(); rebuildKeys(); });

        langRow.addView(btnKu);
        langRow.addView(btnEn);
        langRow.addView(btnAr);
        rootView.addView(langRow);

        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        rootView.addView(keysContainer);

        buildRows();
        return rootView;
    }

    private void rebuildKeys() {
        rootView.removeAllViews();
        LinearLayout suggRow = new LinearLayout(this);
        suggRow.setOrientation(LinearLayout.HORIZONTAL);
        suggRow.setPadding(4,2,4,2);
        HorizontalScrollView scrollSugg = new HorizontalScrollView(this);
        scrollSugg.setBackgroundColor(Color.parseColor("#161b22"));
        for (int i = 0; i < 8; i++) {
            Button s = new Button(this);
            s.setTextColor(Color.parseColor("#58a6ff"));
            s.setTextSize(14);
            s.setTypeface(null, Typeface.BOLD);
            s.setVisibility(View.GONE);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(38));
            sp.setMargins(3,2,3,2);
            s.setLayoutParams(sp);
            s.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#21262d")));
            suggRow.addView(s);
        }
        scrollSugg.addView(suggRow);
        rootView.addView(scrollSugg);
        rootView.setTag(suggRow);
        rootView.addView(langRow);
        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        rootView.addView(keysContainer);
        buildRows();
    }

    private Button makeLangBtn(String text, boolean active) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(40), 1f);
        p.setMargins(2,2,2,2);
        b.setLayoutParams(p);
        b.setBackgroundTintList(ColorStateList.valueOf(
            active ? Color.parseColor("#e94560") : Color.parseColor("#21262d")));
        return b;
    }

    private void updateLang() {
        btnKu.setBackgroundTintList(ColorStateList.valueOf(currentLang==0 ? Color.parseColor("#e94560") : Color.parseColor("#21262d")));
        btnEn.setBackgroundTintList(ColorStateList.valueOf(currentLang==1 ? Color.parseColor("#e94560") : Color.parseColor("#21262d")));
        btnAr.setBackgroundTintList(ColorStateList.valueOf(currentLang==2 ? Color.parseColor("#e94560") : Color.parseColor("#21262d")));
    }

    private void buildRows() {
        keysContainer.removeAllViews();
        String[][] rows = getRows();
        for (int ri = 0; ri < rows.length; ri++) {
            String[] row = rows[ri];
            LinearLayout rowL = new LinearLayout(this);
            rowL.setOrientation(LinearLayout.HORIZONTAL);
            rowL.setGravity(Gravity.CENTER);
            for (String key : row) {
                Button b = new Button(this);
                b.setText(key);
                b.setTextColor(Color.WHITE);
                b.setPadding(1,2,1,2);
                LinearLayout.LayoutParams p;
                int color;
                int textSz;

                if (key.equals("         ")) {
                    p = new LinearLayout.LayoutParams(0, dp(48), 2.5f);
                    color = Color.parseColor("#30363d");
                    textSz = 14;
                } else if (key.equals("⌫")) {
                    p = new LinearLayout.LayoutParams(0, dp(48), 1.5f);
                    color = Color.parseColor("#da3633");
                    textSz = 18;
                } else if (key.equals("↵")) {
                    p = new LinearLayout.LayoutParams(0, dp(48), 1.5f);
                    color = Color.parseColor("#238636");
                    textSz = 16;
                } else if (key.equals("⇧")) {
                    p = new LinearLayout.LayoutParams(0, dp(48), 1.3f);
                    color = isShift ? Color.parseColor("#e94560") : Color.parseColor("#30363d");
                    textSz = 18;
                } else if (key.equals("🗑")) {
                    p = new LinearLayout.LayoutParams(0, dp(48), 1.2f);
                    color = Color.parseColor("#6e4040");
                    textSz = 16;
                } else if (key.equals("📋")) {
                    p = new LinearLayout.LayoutParams(0, dp(48), 1.2f);
                    color = Color.parseColor("#1f4068");
                    textSz = 16;
                } else if (key.equals("Lang")||key.equals("زمان")||key.equals("لغة")) {
                    p = new LinearLayout.LayoutParams(0, dp(48), 1.5f);
                    color = Color.parseColor("#21262d");
                    textSz = 12;
                } else {
                    p = new LinearLayout.LayoutParams(0, dp(48), 1f);
                    color = Color.parseColor("#21262d");
                    textSz = 19;
                }
                p.setMargins(2,2,2,2);
                b.setLayoutParams(p);
                b.setTextSize(textSz);
                b.setTypeface(null, Typeface.BOLD);
                b.setBackgroundTintList(ColorStateList.valueOf(color));
                final String k = key;
                b.setOnClickListener(v -> onKey(k));
                rowL.addView(b);
            }
            keysContainer.addView(rowL);
        }
    }

    private String[][] getRows() {
        if (currentLang==1) return isShift ? englishUp : english;
        if (currentLang==2) return arabic;
        return isShift ? kurdish2 : kurdish;
    }

    private void onKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (key) {
            case "⌫":
                ic.deleteSurroundingText(1,0);
                if (currentWord.length() > 0)
                    currentWord.deleteCharAt(currentWord.length()-1);
                updateSuggestions();
                break;

            case "↵":
                ic.commitText("\n",1);
                currentWord.setLength(0);
                updateSuggestions();
                break;

            case "⇧":
                isShift = !isShift;
                buildRows();
                break;

            case "🗑":
                // Clear all text
                ExtractedText et = ic.getExtractedText(new ExtractedTextRequest(), 0);
                if (et != null && et.text != null) {
                    ic.setSelection(0, et.text.length());
                    ic.commitText("", 1);
                }
                currentWord.setLength(0);
                updateSuggestions();
                break;

            case "📋":
                // Copy all text
                ExtractedText et2 = ic.getExtractedText(new ExtractedTextRequest(), 0);
                if (et2 != null && et2.text != null && et2.text.length() > 0) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("copied", et2.text));
                }
                break;

            case "Lang": case "زمان": case "لغة":
                currentLang = (currentLang+1)%3;
                isShift = false;
                updateLang();
                rebuildKeys();
                break;

            case "         ":
                ic.commitText(" ",1);
                currentWord.setLength(0);
                updateSuggestions();
                break;

            default:
                ic.commitText(key,1);
                if (isShift && currentLang==1) { isShift=false; buildRows(); }
                // Track current word for suggestions
                if (currentLang == 0) {
                    currentWord.append(key);
                    updateSuggestions();
                }
        }
    }

    private void updateSuggestions() {
        if (rootView == null) return;
        LinearLayout suggRow = (LinearLayout) rootView.getTag();
        if (suggRow == null) return;

        String typed = currentWord.toString();
        int count = 0;

        for (int i = 0; i < suggRow.getChildCount(); i++) {
            Button s = (Button) suggRow.getChildAt(i);
            s.setVisibility(View.GONE);
        }

        if (typed.length() == 0) return;

        int btnIdx = 0;
        for (String word : kurdishWords) {
            if (word.startsWith(typed) && !word.equals(typed)) {
                if (btnIdx < suggRow.getChildCount()) {
                    Button s = (Button) suggRow.getChildAt(btnIdx);
                    s.setText(word);
                    s.setVisibility(View.VISIBLE);
                    final String w = word;
                    s.setOnClickListener(v -> {
                        InputConnection ic2 = getCurrentInputConnection();
                        if (ic2 != null) {
                            // Delete current typed word first
                            ic2.deleteSurroundingText(currentWord.length(), 0);
                            ic2.commitText(w + " ", 1);
                            currentWord.setLength(0);
                            updateSuggestions();
                        }
                    });
                    btnIdx++;
                    if (btnIdx >= suggRow.getChildCount()) break;
                }
            }
        }
    }

    private int dp(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
