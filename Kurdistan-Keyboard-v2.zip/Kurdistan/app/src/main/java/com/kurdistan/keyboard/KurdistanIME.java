package com.kurdistan.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;
import android.util.TypedValue;

public class KurdistanIME extends InputMethodService {

    private static final int LANG_KURDISH = 0;
    private static final int LANG_ENGLISH = 1;
    private static final int LANG_ARABIC = 2;

    private int currentLang = LANG_KURDISH;
    private boolean isShift = false;
    private LinearLayout keysContainer;
    private Button btnKurdish, btnEnglish, btnArabic;

    // Kurdish Sorani keyboard rows
    private final String[][] kurdishRows = {
        {"ق", "و", "ئ", "ر", "ت", "ی", "ئو", "ی", "ۆ", "پ", "⌫"},
        {"ا", "س", "د", "ف", "گ", "ه", "ج", "ک", "ل", "؛"},
        {"⇧", "ز", "خ", "چ", "ڤ", "ب", "ن", "م", "،", "."},
        {"زمان", "   فراغ   ", "Enter"}
    };

    private final String[][] kurdishRows2 = {
        {"ژ", "ێ", "ع", "ڕ", "ت", "ی", "ئو", "ی", "ۆ", "پ", "⌫"},
        {"ا", "ش", "د", "ف", "غ", "ه", "ج", "ک", "ل", "؛"},
        {"⇧", "ز", "خ", "چ", "ڤ", "ب", "ن", "م", "،", "."},
        {"زمان", "   فراغ   ", "Enter"}
    };

    // English keyboard rows
    private final String[][] englishRows = {
        {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p", "⌫"},
        {"a", "s", "d", "f", "g", "h", "j", "k", "l", ";"},
        {"⇧", "z", "x", "c", "v", "b", "n", "m", ",", "."},
        {"Lang", "       Space       ", "Enter"}
    };

    private final String[][] englishRowsUpper = {
        {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "⌫"},
        {"A", "S", "D", "F", "G", "H", "J", "K", "L", ":"},
        {"⇧", "Z", "X", "C", "V", "B", "N", "M", "<", ">"},
        {"Lang", "       Space       ", "Enter"}
    };

    // Arabic keyboard rows
    private final String[][] arabicRows = {
        {"ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "⌫"},
        {"ش", "س", "ي", "ب", "ل", "ا", "ت", "ن", "م", "ك"},
        {"⇧", "ئ", "ء", "ؤ", "ر", "ى", "ة", "و", "ز", "ظ"},
        {"لغة", "   مسافة   ", "Enter"}
    };

    @Override
    public View onCreateInputView() {
        View rootView = getLayoutInflater().inflate(R.layout.keyboard_view, null);
        keysContainer = rootView.findViewById(R.id.keys_container);
        btnKurdish = rootView.findViewById(R.id.btn_kurdish);
        btnEnglish = rootView.findViewById(R.id.btn_english);
        btnArabic = rootView.findViewById(R.id.btn_arabic);

        btnKurdish.setOnClickListener(v -> switchLanguage(LANG_KURDISH));
        btnEnglish.setOnClickListener(v -> switchLanguage(LANG_ENGLISH));
        btnArabic.setOnClickListener(v -> switchLanguage(LANG_ARABIC));

        buildKeyboard();
        return rootView;
    }

    private void switchLanguage(int lang) {
        currentLang = lang;
        isShift = false;
        updateLangButtons();
        buildKeyboard();
    }

    private void updateLangButtons() {
        int active = Color.parseColor("#e94560");
        int inactive = Color.parseColor("#16213e");
        btnKurdish.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                currentLang == LANG_KURDISH ? active : inactive));
        btnEnglish.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                currentLang == LANG_ENGLISH ? active : inactive));
        btnArabic.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                currentLang == LANG_ARABIC ? active : inactive));
    }

    private void buildKeyboard() {
        keysContainer.removeAllViews();
        String[][] rows = getRows();

        for (String[] row : rows) {
            LinearLayout rowLayout = new LinearLayout(this);
            rowLayout.setOrientation(LinearLayout.HORIZONTAL);
            rowLayout.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            rowParams.setMargins(2, 2, 2, 2);
            rowLayout.setLayoutParams(rowParams);

            for (String key : row) {
                Button btn = new Button(this);
                btn.setText(key);
                btn.setTextColor(Color.WHITE);
                btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, key.length() > 2 ? 13 : 16);
                btn.setPadding(2, 8, 2, 8);

                LinearLayout.LayoutParams params;
                if (key.contains("Space") || key.contains("فراغ") || key.contains("مسافة")) {
                    params = new LinearLayout.LayoutParams(0, dpToPx(44), 3f);
                    btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            Color.parseColor("#0f3460")));
                } else if (key.equals("⌫")) {
                    params = new LinearLayout.LayoutParams(0, dpToPx(44), 1.5f);
                    btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            Color.parseColor("#e94560")));
                } else if (key.equals("Enter")) {
                    params = new LinearLayout.LayoutParams(0, dpToPx(44), 1.5f);
                    btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            Color.parseColor("#e94560")));
                } else if (key.equals("⇧")) {
                    params = new LinearLayout.LayoutParams(0, dpToPx(44), 1f);
                    btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            isShift ? Color.parseColor("#e94560") : Color.parseColor("#16213e")));
                } else if (key.equals("Lang") || key.equals("زمان") || key.equals("لغة")) {
                    params = new LinearLayout.LayoutParams(0, dpToPx(44), 1.5f);
                    btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            Color.parseColor("#16213e")));
                } else {
                    params = new LinearLayout.LayoutParams(0, dpToPx(44), 1f);
                    btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                            Color.parseColor("#16213e")));
                }

                params.setMargins(2, 2, 2, 2);
                btn.setLayoutParams(params);
                btn.setOnClickListener(v -> handleKey(key));
                rowLayout.addView(btn);
            }
            keysContainer.addView(rowLayout);
        }
    }

    private String[][] getRows() {
        switch (currentLang) {
            case LANG_ENGLISH:
                return isShift ? englishRowsUpper : englishRows;
            case LANG_ARABIC:
                return arabicRows;
            default:
                return isShift ? kurdishRows2 : kurdishRows;
        }
    }

    private void handleKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        switch (key) {
            case "⌫":
                ic.deleteSurroundingText(1, 0);
                break;
            case "Enter":
                ic.commitText("\n", 1);
                break;
            case "⇧":
                isShift = !isShift;
                buildKeyboard();
                break;
            case "Lang":
            case "زمان":
            case "لغة":
                currentLang = (currentLang + 1) % 3;
                isShift = false;
                updateLangButtons();
                buildKeyboard();
                break;
            default:
                String text = key.trim();
                if (text.contains("Space") || text.contains("فراغ") || text.contains("مسافة")) {
                    ic.commitText(" ", 1);
                } else {
                    ic.commitText(text, 1);
                    if (isShift && currentLang == LANG_ENGLISH) {
                        isShift = false;
                        buildKeyboard();
                    }
                }
                break;
        }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}
