package com.kurdistan.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;

public class SettingsActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.parseColor("#1a1a2e"));
        layout.setPadding(40, 60, 40, 60);

        TextView title = new TextView(this);
        title.setText("🌟 Kurdistan Keyboard");
        title.setTextColor(Color.WHITE);
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);

        TextView subtitle = new TextView(this);
        subtitle.setText("کوردی • English • عربی");
        subtitle.setTextColor(Color.parseColor("#e94560"));
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 10, 0, 40);

        TextView step1 = new TextView(this);
        step1.setText("📋 پێوەرە ١: چالاک کردنی کیبۆرد\nSettings → General Management → Keyboard list and default → Kurdistan Keyboard چالاکی بکە");
        step1.setTextColor(Color.parseColor("#cccccc"));
        step1.setTextSize(14);
        step1.setPadding(0, 0, 0, 20);

        Button btnEnable = new Button(this);
        btnEnable.setText("⚙️ کردنەوەی Settings");
        btnEnable.setTextColor(Color.WHITE);
        btnEnable.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                Color.parseColor("#e94560")));
        btnEnable.setOnClickListener(v -> {
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS));
        });

        TextView step2 = new TextView(this);
        step2.setText("\n📋 پێوەرە ٢: هەڵبژاردنی کیبۆرد\nلە هەموو ئاپێکدا دوگمەی کیبۆرد لە خوارەوە پێچ بگرە بۆ هەڵبژاردنی Kurdistan");
        step2.setTextColor(Color.parseColor("#cccccc"));
        step2.setTextSize(14);
        step2.setPadding(0, 20, 0, 0);

        layout.addView(title);
        layout.addView(subtitle);
        layout.addView(step1);
        layout.addView(btnEnable);
        layout.addView(step2);

        setContentView(layout);
    }
}
