# 🌟 Kurdistan Keyboard - کیبۆردی کوردستان

کیبۆردی ئەندرۆید بۆ سێ زمان:
- **کوردی سۆرانی** ☑️
- **English** ☑️  
- **عربی** ☑️

## چۆن APK وەربگیری (بێ Android Studio)

### ١. کۆدەکە بنێ لە GitHub
1. بچۆ [github.com](https://github.com) و لۆگین بکە
2. "New repository" دابکە
3. ناوی بنووسە: `Kurdistan`
4. "Create repository" دابکە
5. هەموو فایلەکانی ئەم فۆڵدەرە ئەپلۆد بکە

### ٢. GitHub Actions ئۆتۆماتیک Build دەکات
- کاتێک فایلەکان ئەپلۆد دەکەیت
- GitHub Actions دەست پێ دەکات
- ٥-١٠ خولەک چاوەڕوان بکە

### ٣. APK داونلۆد بکە
1. لە GitHub، بکە لەسەر "Actions"
2. کلیک لەسەر دوایین build
3. خوارەوە "Kurdistan-Keyboard-APK" داونلۆد بکە

## چۆن نصب بکەیت
1. فایلی APK لە موبایلەکەت کردنەوە
2. "Install from unknown sources" چالاک بکە
3. نصب بکە

## چۆن چالاک بکەیت
1. Settings → General Management
2. Keyboard list and default
3. Kurdistan Keyboard چالاک بکە ✅
4. لە هەموو ئاپێکدا کیبۆردەکە بەکاربهێنە 🎉
