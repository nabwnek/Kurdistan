package com.kurdistan.keyboard;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(Color.parseColor("#1a1a2e"));
        layout.setPadding(48, 80, 48, 48);

        TextView title = new TextView(this);
        title.setText("🌟 Kurdistan Keyboard");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView sub = new TextView(this);
        sub.setText("کوردی • English • عربی");
        sub.setTextColor(Color.parseColor("#e94560"));
        sub.setTextSize(16);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0,8,0,40);
        layout.addView(sub);

        TextView info = new TextView(this);
        info.setText("بۆ چالاک کردن:\nSettings → General Management → Keyboard list → Kurdistan Keyboard");
        info.setTextColor(Color.parseColor("#cccccc"));
        info.setTextSize(14);
        info.setPadding(0,0,0,24);
        layout.addView(info);

        Button btn = new Button(this);
        btn.setText("⚙️ بچۆ Settings");
        btn.setTextColor(Color.WHITE);
        btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#e94560")));
        btn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        layout.addView(btn);

        setContentView(layout);
    }
}
