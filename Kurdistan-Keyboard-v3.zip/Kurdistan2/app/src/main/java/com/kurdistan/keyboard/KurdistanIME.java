package com.kurdistan.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;
import android.content.res.ColorStateList;

public class KurdistanIME extends InputMethodService {

    private int currentLang = 0; // 0=Kurdish, 1=English, 2=Arabic
    private boolean isShift = false;
    private LinearLayout keysContainer;
    private Button btnKu, btnEn, btnAr;

    private final String[][] kurdish = {
        {"ق","و","ئ","ر","ت","ی","ئو","ی","ۆ","پ","⌫"},
        {"ا","س","د","ف","گ","ه","ج","ک","ل","؛"},
        {"⇧","ز","خ","چ","ڤ","ب","ن","م","،","."},
        {"زمان","         ","↵"}
    };
    private final String[][] kurdish2 = {
        {"ژ","ێ","ع","ڕ","ت","ی","ئو","ی","ۆ","پ","⌫"},
        {"ا","ش","د","ف","غ","ه","ج","ک","ل","؛"},
        {"⇧","ز","خ","چ","ڤ","ب","ن","م","،","."},
        {"زمان","         ","↵"}
    };
    private final String[][] english = {
        {"q","w","e","r","t","y","u","i","o","p","⌫"},
        {"a","s","d","f","g","h","j","k","l",";"},
        {"⇧","z","x","c","v","b","n","m",",","."},
        {"Lang","         ","↵"}
    };
    private final String[][] englishUp = {
        {"Q","W","E","R","T","Y","U","I","O","P","⌫"},
        {"A","S","D","F","G","H","J","K","L",":"},
        {"⇧","Z","X","C","V","B","N","M","<",">"},
        {"Lang","         ","↵"}
    };
    private final String[][] arabic = {
        {"ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","⌫"},
        {"ش","س","ي","ب","ل","ا","ت","ن","م","ك"},
        {"⇧","ئ","ء","ؤ","ر","ى","ة","و","ز","ظ"},
        {"لغة","         ","↵"}
    };

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#1a1a2e"));
        root.setPadding(4,4,4,4);

        // Lang buttons
        LinearLayout langRow = new LinearLayout(this);
        langRow.setOrientation(LinearLayout.HORIZONTAL);

        btnKu = makeLangBtn("کوردی", true);
        btnEn = makeLangBtn("English", false);
        btnAr = makeLangBtn("عربی", false);

        btnKu.setOnClickListener(v -> { currentLang=0; isShift=false; updateLang(); buildKeys(root, langRow); });
        btnEn.setOnClickListener(v -> { currentLang=1; isShift=false; updateLang(); buildKeys(root, langRow); });
        btnAr.setOnClickListener(v -> { currentLang=2; isShift=false; updateLang(); buildKeys(root, langRow); });

        langRow.addView(btnKu);
        langRow.addView(btnEn);
        langRow.addView(btnAr);
        root.addView(langRow);

        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(keysContainer);

        buildRows();
        return root;
    }

    private Button makeLangBtn(String text, boolean active) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(36), 1f);
        p.setMargins(2,2,2,2);
        b.setLayoutParams(p);
        b.setBackgroundTintList(ColorStateList.valueOf(
            active ? Color.parseColor("#e94560") : Color.parseColor("#16213e")));
        return b;
    }

    private void updateLang() {
        btnKu.setBackgroundTintList(ColorStateList.valueOf(currentLang==0 ? Color.parseColor("#e94560") : Color.parseColor("#16213e")));
        btnEn.setBackgroundTintList(ColorStateList.valueOf(currentLang==1 ? Color.parseColor("#e94560") : Color.parseColor("#16213e")));
        btnAr.setBackgroundTintList(ColorStateList.valueOf(currentLang==2 ? Color.parseColor("#e94560") : Color.parseColor("#16213e")));
    }

    private void buildKeys(LinearLayout root, LinearLayout langRow) {
        root.removeAllViews();
        root.addView(langRow);
        keysContainer = new LinearLayout(this);
        keysContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(keysContainer);
        buildRows();
    }

    private void buildRows() {
        keysContainer.removeAllViews();
        String[][] rows = getRows();
        for (String[] row : rows) {
            LinearLayout rowL = new LinearLayout(this);
            rowL.setOrientation(LinearLayout.HORIZONTAL);
            rowL.setGravity(Gravity.CENTER);
            for (String key : row) {
                Button b = new Button(this);
                b.setText(key);
                b.setTextColor(Color.WHITE);
                b.setTextSize(key.length() > 2 ? 11 : 15);
                b.setPadding(2,4,2,4);
                LinearLayout.LayoutParams p;
                int color;
                if (key.equals("         ")) {
                    p = new LinearLayout.LayoutParams(0, dp(42), 3f);
                    color = Color.parseColor("#0f3460");
                } else if (key.equals("⌫") || key.equals("↵")) {
                    p = new LinearLayout.LayoutParams(0, dp(42), 1.5f);
                    color = Color.parseColor("#e94560");
                } else if (key.equals("⇧")) {
                    p = new LinearLayout.LayoutParams(0, dp(42), 1f);
                    color = isShift ? Color.parseColor("#e94560") : Color.parseColor("#16213e");
                } else if (key.equals("Lang")||key.equals("زمان")||key.equals("لغة")) {
                    p = new LinearLayout.LayoutParams(0, dp(42), 1.5f);
                    color = Color.parseColor("#16213e");
                } else {
                    p = new LinearLayout.LayoutParams(0, dp(42), 1f);
                    color = Color.parseColor("#16213e");
                }
                p.setMargins(2,2,2,2);
                b.setLayoutParams(p);
                b.setBackgroundTintList(ColorStateList.valueOf(color));
                final String k = key;
                b.setOnClickListener(v -> onKey(k));
                rowL.addView(b);
            }
            keysContainer.addView(rowL);
        }
    }

    private String[][] getRows() {
        if (currentLang==1) return isShift ? englishUp : english;
        if (currentLang==2) return arabic;
        return isShift ? kurdish2 : kurdish;
    }

    private void onKey(String key) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        switch (key) {
            case "⌫": ic.deleteSurroundingText(1,0); break;
            case "↵": ic.commitText("\n",1); break;
            case "⇧":
                isShift = !isShift;
                buildRows();
                break;
            case "Lang": case "زمان": case "لغة":
                currentLang = (currentLang+1)%3;
                isShift = false;
                updateLang();
                buildRows();
                break;
            case "         ": ic.commitText(" ",1); break;
            default: ic.commitText(key,1);
                if (isShift && currentLang==1) { isShift=false; buildRows(); }
        }
    }

    private int dp(int dp) {
        return (int)(dp * getResources().getDisplayMetrics().density);
    }
}
